<?php
// HTTP
define('HTTP_SERVER', 'http://b916236o.beget.tech/admin/');
define('HTTP_CATALOG', 'http://b916236o.beget.tech/');

// HTTPS
define('HTTPS_SERVER', 'http://b916236o.beget.tech/admin/');
define('HTTPS_CATALOG', 'http://b916236o.beget.tech/');

// DIR
define('DIR_APPLICATION', '/home/b/b916236o/b916236o.beget.tech/public_html/admin/');
define('DIR_SYSTEM', '/home/b/b916236o/b916236o.beget.tech/public_html/system/');
define('DIR_IMAGE', '/home/b/b916236o/b916236o.beget.tech/public_html/image/');
define('DIR_LANGUAGE', '/home/b/b916236o/b916236o.beget.tech/public_html/admin/language/');
define('DIR_TEMPLATE', '/home/b/b916236o/b916236o.beget.tech/public_html/admin/view/template/');
define('DIR_CONFIG', '/home/b/b916236o/b916236o.beget.tech/public_html/system/config/');
define('DIR_CACHE', '/home/b/b916236o/b916236o.beget.tech/public_html/system/storage/cache/');
define('DIR_DOWNLOAD', '/home/b/b916236o/b916236o.beget.tech/public_html/system/storage/download/');
define('DIR_LOGS', '/home/b/b916236o/b916236o.beget.tech/public_html/system/storage/logs/');
define('DIR_MODIFICATION', '/home/b/b916236o/b916236o.beget.tech/public_html/system/storage/modification/');
define('DIR_UPLOAD', '/home/b/b916236o/b916236o.beget.tech/public_html/system/storage/upload/');
define('DIR_CATALOG', '/home/b/b916236o/b916236o.beget.tech/public_html/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'b916236o_fg');
define('DB_PASSWORD', 'todestodes2012');
define('DB_DATABASE', 'b916236o_fg');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
