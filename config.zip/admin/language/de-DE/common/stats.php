<?php
/**
 * @version		$Id: stats.php 3902 2015-04-06 20:11:56Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['text_complete_status']		= 'Aufträge Abgeschlossen';
$_['text_processing_status']	= 'Aufträge in Arbeit';
$_['text_other_status']			= 'Andere Statusse';