<?php
// Heading
$_['heading_title']     = 'TemplateMonster Newsletter';

// Text
$_['text_module']       = 'Module';
$_['text_success']      = 'Erfolg: Sie haben das Templatemonster Newsletter Modul verändert!';
$_['text_edit']         = 'TemplateMonster Newsletter Modul ändern';

// Entry
$_['entry_status']      = 'Status';
$_['entry_name']        = 'Modulename';
$_['entry_description'] = 'Beschreibung';

// Error
$_['error_permission']  = 'Achtung: Sie haben keine Berechtigung das Templatemonster Newsletter Modul zu ändern!';
$_['error_name']        = 'Modulname muss 3 bis 64 Zeichen haben!';